# -*- coding: utf-8 -*-
# Coded Using Ai Tools *** Ismail9875 ***
# *** *** *** *** *** ***
#       3 Dec 2025      
# *** *** *** *** *** ***
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ProgressBar import ProgressBar
from Components.config import config, ConfigSubsection, ConfigText, getConfigListEntry
from Components.ConfigList import ConfigList
from Components.Sources.StaticText import StaticText
from datetime import datetime
import binascii
import os
import re
import zlib
from array import array
import subprocess
import signal
import shutil
import time
from enigma import eServiceReference, iServiceInformation, eServiceCenter, eDVBDB, gRGB, eTimer

# =============================================
# دالة الكشف الذكي عن مسارات SoftCam.Key
# =============================================
def detect_softcam_key_paths():
    """الكشف عن جميع مسارات SoftCam.Key الموجودة على النظام"""
    
    # قائمة شاملة بجميع المسارات المحتملة لملفات SoftCam.Key
    # مرتبة حسب الأهمية والشيوع
    all_possible_paths = [
        # 1. المسارات القياسية الحديثة (OE-2.5+ / DreamOS)
        "/etc/tuxbox/config/SoftCam.Key",
        "/etc/tuxbox/config/oscam/SoftCam.Key",
        "/etc/tuxbox/config/ncam/SoftCam.Key",
        "/etc/tuxbox/config/cccam/SoftCam.Key",
        "/etc/tuxbox/config/mgcamd/SoftCam.Key",
        
        # 2. مسارات OSCam المخصصة
        "/usr/keys/SoftCam.Key",
        "/usr/keys/oscam/SoftCam.Key",
        "/usr/local/keys/SoftCam.Key",
        "/var/keys/SoftCam.Key",
        "/var/oscam/SoftCam.Key",
        
        # 3. المسارات القديمة (OE-1.6 / OE-2.0)
        "/etc/SoftCam.Key",
        "/var/etc/SoftCam.Key",
        "/var/tuxbox/config/SoftCam.Key",
        "/var/tuxbox/config/oscam/SoftCam.Key",
        
        # 4. مسارات خاصة بالصور المختلفة
        "/etc/cccam/SoftCam.Key",           # للصور التي تستخدم CCcam
        "/etc/mgcamd/SoftCam.Key",          # للصور التي تستخدم Mgcamd
        "/etc/camd3/SoftCam.Key",           # للصور القديمة
        
        # 5. مسارات المستخدم والجذر
        "/home/root/SoftCam.Key",
        "/root/SoftCam.Key",
        
        # 6. مسارات إضافية
        "/usr/emu/SoftCam.Key",
        "/usr/scam/SoftCam.Key",
        "/usr/camscript/SoftCam.Key",
        
        # 7. مسارات خاصة بأنواع محددة من المحاكيات
        "/etc/gbox/SoftCam.Key",
        "/etc/wicardd/SoftCam.Key",
        "/etc/cam/SoftCam.Key",
        
        # 8. مسارات النسخ الاحتياطية
        "/etc/tuxbox/config/SoftCam.Key.bak",
        "/usr/keys/SoftCam.Key.bak",
        "/etc/SoftCam.Key.bak",
    ]
    
    # تصفية فقط المسارات الموجودة فعلياً
    found_paths = []
    for path in all_possible_paths:
        if os.path.exists(path):
            # التحقق من أن الملف قابل للكتابة
            if os.access(os.path.dirname(path) if os.path.dirname(path) else '/', os.W_OK):
                found_paths.append(path)
            else:
                print(f"Found but not writable: {path}")
    
    return found_paths


def get_default_path_for_image():
    """الحصول على المسار الافتراضي بناءً على نوع الصورة"""
    
    # محاولة اكتشاف نوع الصورة من ملفات النظام
    image_info = {
        "openatv": "/etc/image-version",
        "openpli": "/etc/issue",
        "openvix": "/etc/vixversion",
        "openbh": "/etc/bhversion",
        "openvision": "/etc/visionversion",
        "pure2": "/etc/pure2version",
        "egami": "/etc/egamiversion",
        "satdreamgr": "/etc/sdversion",
        "blackhole": "/etc/bhversion",
    }
    
    detected_image = "unknown"
    
    # محاولة الكشف عن الصورة
    for image_name, version_file in image_info.items():
        if os.path.exists(version_file):
            detected_image = image_name
            break
    
    print(f"Detected image: {detected_image}")
    
    # مسارات افتراضية بناءً على الصورة المكتشفة
    default_paths = {
        "openatv": "/etc/tuxbox/config/SoftCam.Key",
        "openpli": "/etc/tuxbox/config/SoftCam.Key",
        "openvix": "/etc/tuxbox/config/SoftCam.Key",
        "openbh": "/etc/tuxbox/config/SoftCam.Key",
        "openvision": "/etc/tuxbox/config/SoftCam.Key",
        "pure2": "/etc/tuxbox/config/SoftCam.Key",
        "egami": "/etc/tuxbox/config/SoftCam.Key",
        "satdreamgr": "/etc/tuxbox/config/SoftCam.Key",
        "blackhole": "/etc/tuxbox/config/SoftCam.Key",
        "unknown": "/etc/tuxbox/config/SoftCam.Key",  # افتراضي
    }
    
    return default_paths.get(detected_image, "/etc/tuxbox/config/SoftCam.Key")


def ensure_softcam_key_file():
    """التأكد من وجود ملف SoftCam.Key وإنشائه إذا لم يكن موجوداً"""
    
    # 1. البحث عن الملفات الموجودة
    found_paths = detect_softcam_key_paths()
    
    if found_paths:
        print(f"Found existing SoftCam.Key files: {found_paths}")
        return found_paths
    
    # 2. إذا لم توجد ملفات، إنشاء ملف جديد في المسار الافتراضي
    default_path = get_default_path_for_image()
    
    print(f"No SoftCam.Key files found. Creating new file at: {default_path}")
    
    try:
        # التأكد من وجود المجلد
        directory = os.path.dirname(default_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
            print(f"Created directory: {directory}")
        
        # إنشاء الملف مع رأسية أساسية
        header = f"""# SoftCam.Key file
# Created by E2 BISS Key Editor
# Creation date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
# 
# Format: F HASH 00 KEY ; Comment
# 
# BISS Keys:
"""
        
        with open(default_path, 'w') as f:
            f.write(header)
        
        print(f"Successfully created SoftCam.Key at: {default_path}")
        
        # جعل الملف قابلاً للكتابة للجميع (اختياري)
        os.chmod(default_path, 0o666)
        
        return [default_path]
        
    except Exception as e:
        print(f"Error creating SoftCam.Key: {e}")
        
        # محاولة مسار بديل
        alternative_paths = [
            "/etc/SoftCam.Key",
            "/usr/keys/SoftCam.Key",
            "/var/keys/SoftCam.Key",
        ]
        
        for alt_path in alternative_paths:
            try:
                directory = os.path.dirname(alt_path)
                if directory and not os.path.exists(directory):
                    os.makedirs(directory, exist_ok=True)
                
                with open(alt_path, 'w') as f:
                    f.write(f"# SoftCam.Key - Created by E2 BISS Key Editor\n")
                
                print(f"Created SoftCam.Key at alternative path: {alt_path}")
                os.chmod(alt_path, 0o666)
                return [alt_path]
                
            except Exception as e2:
                print(f"Failed to create at {alt_path}: {e2}")
                continue
        
        print("ERROR: Could not create SoftCam.Key file!")
        return []


def save_key_to_all_paths(key_line, existing_paths=None):
    """حفظ الشفرة في جميع مسارات SoftCam.Key الموجودة"""
    
    # الحصول على المسارات الموجودة
    if existing_paths is None:
        target_paths = detect_softcam_key_paths()
    else:
        target_paths = existing_paths
    
    # إذا لم توجد مسارات، إنشاء ملف جديد
    if not target_paths:
        target_paths = ensure_softcam_key_file()
        if not target_paths:
            return False, "Failed to create or find SoftCam.Key file"
    
    print(f"Saving key to {len(target_paths)} location(s): {target_paths}")
    
    success_paths = []
    failed_paths = []
    
    for path in target_paths:
        try:
            # نسخ احتياطي للملف الحالي
            #backup_path = f"{path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            #if os.path.exists(path):
            #    shutil.copy2(path, backup_path)
            #    print(f"Backup created: {backup_path}")
            
            # كتابة الشفرة الجديدة
            with open(path, 'a') as f:
                f.write(key_line + '\n')
            
            print(f"✓ Key saved to: {path}")
            success_paths.append(path)
            
        except PermissionError:
            print(f"✗ Permission denied: {path}")
            failed_paths.append((path, "Permission denied"))
            
        except Exception as e:
            print(f"✗ Error saving to {path}: {e}")
            failed_paths.append((path, str(e)))
    
    # إنشاء تقرير النتائج
    if success_paths:
        if len(success_paths) == len(target_paths):
            message = f"Key saved successfully to all {len(success_paths)} locations"
            return True, message
        else:
            message = f"Key saved to {len(success_paths)}/{len(target_paths)} locations\n"
            message += f"Success: {', '.join(success_paths)}\n"
            if failed_paths:
                message += f"Failed: {', '.join([p[0] for p in failed_paths])}"
            return True, message
    else:
        message = f"Failed to save key to any location\n"
        message += f"Errors: {', '.join([f'{p[0]}: {p[1]}' for p in failed_paths])}"
        return False, message

# =============================================
# إعداد حقول الإدخال لكل زوج من الشيفرة
# =============================================
config.biss = ConfigSubsection()
config.biss.cell_a = ConfigText(default="00", fixed_size=2)
config.biss.cell_b = ConfigText(default="00", fixed_size=2)
config.biss.cell_c = ConfigText(default="00", fixed_size=2)
config.biss.cell_d = ConfigText(default="00", fixed_size=2)
config.biss.cell_e = ConfigText(default="00", fixed_size=2)
config.biss.cell_f = ConfigText(default="00", fixed_size=2)
config.biss.cell_g = ConfigText(default="00", fixed_size=2)
config.biss.cell_h = ConfigText(default="00", fixed_size=2)

# إعداد منطق الهاش المختار
config.biss.hash_logic = ConfigText(default="sid+vpi")

# =============================================
# جدول CRC32 المطلوب للحساب (مأخوذ من السكريبت الأصلي)
# =============================================
crc_table = array("L")
for byte in range(256):
    crc = 0
    for bit in range(8):
        if (byte ^ crc) & 1:
            crc = (crc >> 1) ^ 0xEDB88320
        else:
            crc >>= 1
        byte >>= 1
    crc_table.append(crc)

def crc32(string):
    """دالة CRC32 المطابقة للسكريبت الأصلي للكايد 2600"""
    value = 0x2600 ^ 0xffffffff
    if isinstance(string, str):
        # إذا كان النص نصياً، استخدم ord()
        for ch in string:
            value = crc_table[(ord(ch) ^ value) & 0xff] ^ (value >> 8)
    else:
        # إذا كان bytes، استخدم القيم مباشرة
        for ch in string:
            value = crc_table[(ch ^ value) & 0xff] ^ (value >> 8)
    return value ^ 0xffffffff

# =============================================
# دالة إعادة تشغيل المحاكي
# =============================================
def restart_emu():
    """إعادة تشغيل المحاكي بعد حفظ الشفرة - نسخة محسنة"""
    try:
        print("=" * 50)
        print("Starting emulator restart process...")
        print("=" * 50)
        
        # قائمة شاملة لأوامر إعادة تشغيل المحاكي
        restart_commands = [
            # OSCam - الإصدارات المختلفة
            ['systemctl', 'restart', 'oscam'],                # OSCam مع systemd
            ['service', 'oscam', 'restart'],                  # OSCam مع service
            ['/etc/init.d/oscam', 'restart'],                 # OSCam مع init.d
            ['/usr/bin/oscam_restart.sh'],                    # سكريبت OSCam مخصص
            
            # NCam - الإصدارات المختلفة
            ['systemctl', 'restart', 'ncam'],                 # NCam مع systemd
            ['service', 'ncam', 'restart'],                   # NCam مع service
            ['/etc/init.d/ncam', 'restart'],                  # NCam مع init.d
            ['/usr/bin/ncam_restart.sh'],                     # سكريبت NCam مخصص
            
            # CCcam - الإصدارات المختلفة
            ['systemctl', 'restart', 'cccam'],                # CCcam مع systemd
            ['service', 'cccam', 'restart'],                  # CCcam مع service
            ['/etc/init.d/cccam', 'restart'],                 # CCcam مع init.d
            
            # محاكيات أخرى شائعة
            ['systemctl', 'restart', 'mgcamd'],               # Mgcamd
            ['systemctl', 'restart', 'gbox'],                 # Gbox
            ['systemctl', 'restart', 'wicardd'],              # Wicardd
            
            # أوامر عامة للمحاكيات
            ['/etc/init.d/softcam', 'restart'],               # الأمر التقليدي
            ['/etc/init.d/camd', 'restart'],                  # بديل آخر
            ['/usr/bin/restartcam'],                          # سكريبت عام
            ['/usr/bin/cam_restart.sh'],                      # سكريبت بديل
            ['/usr/script/restart_cam.sh'],                   # مسار آخر
            
            # إعادة التشغيل بالقوة (Kill)
            ['pkill', '-9', 'oscam'],                         # OSCam kill
            ['killall', '-9', 'oscam'],                       # OSCam killall
            ['pkill', '-9', 'ncam'],                          # NCam kill
            ['killall', '-9', 'ncam'],                        # NCam killall
            ['pkill', '-9', 'cccam'],                         # CCcam kill
            ['killall', '-9', 'cccam'],                       # CCcam killall
            ['pkill', '-9', 'mgcamd'],                        # Mgcamd kill
            ['killall', '-9', 'mgcamd'],                      # Mgcamd killall
            
            # أوامر محددة لأنظمة Enigma2
            ['init', '4', '&&', 'sleep', '2', '&&', 'init', '3'],  # إعادة تشغيل المستوى
            ['/etc/init.d/rc.local', 'restart'],              # إعادة تشغيل rc.local
        ]
        
        # محاولة إيجاد وإعادة تشغيل المحاكي الفعلي الموجود على النظام
        print("Scanning for running emulators...")
        running_emus = []
        
        # قائمة المحاكيات المحتملة
        possible_emus = ['oscam', 'ncam', 'cccam', 'mgcamd', 'gbox', 'wicardd']
        
        for emu in possible_emus:
            try:
                # التحقق من وجود العملية
                check_proc = subprocess.run(['pgrep', '-x', emu], 
                                          capture_output=True, text=True)
                if check_proc.returncode == 0:
                    running_emus.append(emu)
                    print(f"Found running emulator: {emu} (PID: {check_proc.stdout.strip()})")
            except:
                continue
        
        # إذا وجدنا محاكي يعمل، ركز على إعادة تشغيله
        if running_emus:
            print(f"Found {len(running_emus)} running emulator(s): {', '.join(running_emus)}")
            
            # ترتيب الأوامر حسب المحاكي الموجود
            prioritized_commands = []
            for emu in running_emus:
                # إضافة أوامر systemd للمحاكي الموجود
                prioritized_commands.append(['systemctl', 'restart', emu])
                prioritized_commands.append(['service', emu, 'restart'])
                prioritized_commands.append([f'/etc/init.d/{emu}', 'restart'])
            
            # إضافة الأوامر العامة
            prioritized_commands.extend([
                ['/etc/init.d/softcam', 'restart'],
                ['/usr/bin/restartcam'],
                ['/etc/init.d/camd', 'restart'],
            ])
            
            # محاولة الأوامر ذات الأولوية
            restart_commands = prioritized_commands + restart_commands
        
        # سجل المحاولات
        attempts_log = []
        success = False
        
        print("\nTrying restart commands...")
        print("-" * 40)
        
        # محاولة تنفيذ أوامر إعادة التشغيل
        for idx, cmd in enumerate(restart_commands, 1):
            try:
                cmd_str = ' '.join(cmd)
                print(f"Attempt {idx}: {cmd_str}")
                
                # استخدام shell=True للأوامر المعقدة
                if '&&' in cmd_str:
                    result = subprocess.run(cmd_str, shell=True, 
                                          capture_output=True, text=True, timeout=5)
                else:
                    result = subprocess.run(cmd, capture_output=True, 
                                          text=True, timeout=5)
                
                attempts_log.append({
                    'command': cmd_str,
                    'returncode': result.returncode,
                    'stdout': result.stdout[:100] if result.stdout else '',
                    'stderr': result.stderr[:100] if result.stderr else ''
                })
                
                if result.returncode == 0:
                    print(f"✓ Success with: {cmd_str}")
                    success = True
                    
                    # التحقق من أن المحاكي يعمل بعد إعادة التشغيل
                    if running_emus:
                        time.sleep(3)  # انتظار قليل
                        for emu in running_emus:
                            try:
                                check = subprocess.run(['pgrep', '-x', emu], 
                                                     capture_output=True, text=True)
                                if check.returncode == 0:
                                    print(f"✓ Emulator {emu} is running (PID: {check.stdout.strip()})")
                            except:
                                pass
                    
                    break
                else:
                    print(f"✗ Failed (code: {result.returncode})")
                    
            except subprocess.TimeoutExpired:
                print(f"⚠ Timeout for: {cmd_str}")
                attempts_log.append({
                    'command': cmd_str,
                    'error': 'Timeout'
                })
                continue
            except FileNotFoundError:
                print(f"⚠ Command not found: {cmd_str}")
                attempts_log.append({
                    'command': cmd_str,
                    'error': 'FileNotFound'
                })
                continue
            except PermissionError:
                print(f"⚠ Permission denied: {cmd_str}")
                attempts_log.append({
                    'command': cmd_str,
                    'error': 'PermissionError'
                })
                continue
            except Exception as e:
                print(f"⚠ Error: {str(e)[:50]}...")
                attempts_log.append({
                    'command': cmd_str,
                    'error': str(e)[:100]
                })
                continue
        
        # إذا فشلت جميع الأوامر، حاول بإعادة تشغيل الخدمات العامة
        if not success:
            print("\nTrying fallback methods...")
            print("-" * 40)
            
            fallback_methods = [
                ('systemctl daemon-reload', ['systemctl', 'daemon-reload']),
                ('restart softcam service', ['/etc/init.d/softcam', 'restart']),
                ('restart camd service', ['/etc/init.d/camd', 'restart']),
                ('killall softcam processes', ['pkill', '-9', 'softcam']),
                ('force restart with init', ['init', '4', '&&', 'sleep', '2', '&&', 'init', '3']),
            ]
            
            for method_name, cmd in fallback_methods:
                try:
                    print(f"Fallback: {method_name}")
                    if isinstance(cmd, list) and '&&' in ' '.join(cmd):
                        subprocess.run(' '.join(cmd), shell=True, timeout=10)
                    else:
                        subprocess.run(cmd, timeout=5)
                    
                    print(f"✓ Fallback {method_name} executed")
                    
                    # انتظار وتأكيد
                    time.sleep(2)
                    
                    # التحقق من وجود أي محاكي يعمل
                    for emu in possible_emus:
                        try:
                            check = subprocess.run(['pgrep', emu], 
                                                 capture_output=True, text=True)
                            if check.returncode == 0:
                                print(f"✓ Found {emu} after fallback")
                                success = True
                        except:
                            continue
                    
                    if success:
                        break
                        
                except Exception as e:
                    print(f"✗ Fallback failed: {str(e)[:50]}...")
                    continue
        
        # تسجيل النتائج
        print("\n" + "=" * 50)
        print("RESTART PROCESS SUMMARY")
        print("=" * 50)
        print(f"Total attempts: {len(attempts_log)}")
        print(f"Success: {'YES' if success else 'NO'}")
        
        if not success:
            print("\nFailed attempts details:")
            for attempt in attempts_log[-5:]:  # عرض آخر 5 محاولات فاشلة
                if 'error' in attempt:
                    print(f"  - {attempt['command'][:50]}... : {attempt['error']}")
                else:
                    print(f"  - {attempt['command'][:50]}... : Code {attempt['returncode']}")
        
        print("\n" + "=" * 50)
        
        if success:
            # إضافة رسالة نجاح إضافية
            print("Emulator restart completed successfully!")
            
            # محاولة تحديث قاعدة بيانات الخدمات
            try:
                print("Updating service database...")
                db = eDVBDB.getInstance()
                db.reloadServicelist()
                print("✓ Service database updated")
            except:
                print("⚠ Could not update service database (non-critical)")
        
        return success
        
    except Exception as e:
        print(f"Critical error in restart_emu: {e}")
        import traceback
        traceback.print_exc()
        return False

# =============================================
# دالة تفريغ الخانات تلقائياً عند بدء التشغيل
# =============================================
def auto_reset_all_cells():
    """تفريغ جميع الخانات إلى الحالة الافتراضية (00)"""
    try:
        config.biss.cell_a.value = "00"
        config.biss.cell_b.value = "00"
        config.biss.cell_c.value = "00"
        config.biss.cell_d.value = "00"
        config.biss.cell_e.value = "00"
        config.biss.cell_f.value = "00"
        config.biss.cell_g.value = "00"
        config.biss.cell_h.value = "00"
        config.biss.save()
        print("BISS cells auto-reset to default values")
    except Exception as e:
        print(f"Error in auto reset: {e}")

# =============================================
# BISS-CA 8-Cell Key Validation & Auto-Fix (Correct 2028 Logic)
# Cell d = (a + b + c) & 0xFF
# Cell h = (e + f + g) & 0xFF
# =============================================
def validate_and_fix_biss_8cells(cells):
    """التحقق من صحة الشيفرة وتصحيحها تلقائياً"""
    try:
        a, b, c, d, e, f, g, h = cells
        
        # التحقق من أن جميع الخلايا تحتوي على قيم hex صالحة
        for i, cell in enumerate(cells):
            if not re.match(r'^[0-9A-Fa-f]{2}$', cell):
                return None, False, f"Invalid hex pair in cell {i+1}: {cell}. Must be exactly 2 hex characters."

        # تحويل القيم إلى أعداد
        A = int(a, 16)
        B = int(b, 16)
        C = int(c, 16)
        D = int(d, 16)
        E = int(e, 16)
        F_val = int(f, 16)
        G = int(g, 16)
        H = int(h, 16)

        # حساب القيم الصحيحة
        d_correct = (A + B + C) & 0xFF
        h_correct = (E + F_val + G) & 0xFF

        d_should = f"{d_correct:02X}"
        h_should = f"{h_correct:02X}"

        # إنشاء الخلايا المصححة
        fixed_cells = [a, b, c, d_should, e, f, g, h_should]
        fixed_key = "".join(fixed_cells)
        pretty_key = " ".join(fixed_cells)

        # التحقق من الأخطاء
        errors = []
        if d.upper() != d_should:
            errors.append(f"Cell d → should be {d_should} (was {d})")
        if h.upper() != h_should:
            errors.append(f"Cell h → should be {h_should} (was {h})")

        if not errors:
            return fixed_cells, True, f"Key is 100% valid\n{pretty_key}"

        msg = "\n".join(errors) + f"\n\nAuto-fixed key:\n{pretty_key}"
        return fixed_cells, False, msg

    except Exception as e:
        return None, False, f"Validation error: {str(e)}"

def get_service_info(session):
    """الحصول على معلومات الخدمة الحالية بطريقة محسنة"""
    try:
        service = session.nav.getCurrentService()
        if not service:
            return None, "No service", 0, 0, 0, 0, 0, False

        # الحصول على المرجع الحالي
        service_ref = session.nav.getCurrentlyPlayingServiceReference()
        if not service_ref:
            return None, "No service reference", 0, 0, 0, 0, 0, False

        # الحصول على SID
        sid = service_ref.getUnsignedData(1)  # SID
        
        # الحصول على TSID و ONID و Namespace
        tsid = service_ref.getUnsignedData(2)  # TSID
        onid = service_ref.getUnsignedData(3)  # ONID
        namespace = service_ref.getUnsignedData(4)  # Namespace
        
        # الحصول على اسم القناة
        service_handler = eServiceCenter.getInstance()
        service_info = service_handler.info(service_ref)
        channel_name = service_info.getName(service_ref) if service_info else "Unknown"

        # الحصول على معلومات الخدمة
        info = service.info()
        if not info:
            return channel_name, sid, 0, 0, 0, namespace, False

        # الحصول على PIDs
        vpid = info.getInfo(iServiceInformation.sVideoPID)
        apid = info.getInfo(iServiceInformation.sAudioPID)
        pmtpid = info.getInfo(iServiceInformation.sPMTPID)
        
        # تصحيح القيم غير الصالحة
        if vpid == -1 or vpid >= 8192:
            vpid = 0
        if apid == -1:
            apid = 0
        if pmtpid == -1:
            pmtpid = 0

        # التحقق من حالة التشفير
        is_encrypted = info.getInfo(iServiceInformation.sIsCrypted) == 1

        print(f"Service Info - Name: {channel_name}, SID: {sid:04X}, VPID: {vpid:04X}, APID: {apid:04X}, PMT: {pmtpid:04X}, Namespace: {namespace:08X}, Encrypted: {is_encrypted}")
        
        return channel_name, sid, vpid, apid, pmtpid, namespace, is_encrypted

    except Exception as e:
        print(f"Error getting service info: {e}")
        return None, "Error", 0, 0, 0, 0, 0, False

def get_orbital_position(session):
    """الحصول على الموقع المداري للقناة (مأخوذ من السكريبت الأصلي)"""
    ref = session.nav.getCurrentlyPlayingServiceReference()
    orbpos = ref.getUnsignedData(4) >> 16
    if orbpos == 0xFFFF:
        desc = "C"
    elif orbpos == 0xEEEE:
        desc = "T"
    else:
        if orbpos > 1800:
            orbpos = 3600 - orbpos
            h = "W"
        else:
            h = "E"
        desc = ("%d.%d%s") % (orbpos / 10, orbpos % 10, h)
    return desc

def get_hash_original(session):
    """دالة حساب الهاش الأصلية من السكريبت (للكايد 2600)"""
    ref = session.nav.getCurrentlyPlayingServiceReference()
    sid = ref.getUnsignedData(1)
    tsid = ref.getUnsignedData(2)
    onid = ref.getUnsignedData(3)
    namespace = ref.getUnsignedData(4) | 0xA0000000

    # check if we have stripped or full namespace
    if namespace & 0xFFFF == 0:
        # Namespace without frequency - Calculate hash with srvid, tsid, onid and namespace
        data = "%04X%04X%04X%08X" % (sid, tsid, onid, namespace)
    else:
        # Full namespace - Calculate hash with srvid and namespace only
        data = "%04X%08X" % (sid, namespace)
    
    # استخدام دالة CRC32 الأصلية مع البيانات كـ bytes
    data_bytes = binascii.unhexlify(data)
    return crc32(data_bytes)

def get_selected_hash(session):
    """الحصول على الهاش بناءً على المنطق المختار"""
    try:
        channel_name, sid, vpid, apid, pmtpid, namespace, is_encrypted = get_service_info(session)
        
        if sid == 0:
            return None, "Cannot get SID from current service"
        
        hash_logic = config.biss.hash_logic.value
        hash_value = None
        logic_name = ""
        
        print(f"Generating hash with logic: {hash_logic}")
        print(f"Available PIDs - SID: {sid:04X}, VPID: {vpid:04X}, APID: {apid:04X}, PMT: {pmtpid:04X}, Namespace: {namespace:08X}")
        
        if hash_logic == "sid+vpi":
            # SID + VPID
            if vpid > 0:
                hash_value = f"{sid:04X}{vpid:04X}"
                logic_name = f"SID ({sid:04X}) + VPID ({vpid:04X})"
            else:
                return None, "VPID not available for current service"
                
        elif hash_logic == "sid+apid":
            # SID + APID
            if apid > 0:
                hash_value = f"{sid:04X}{apid:04X}"
                logic_name = f"SID ({sid:04X}) + APID ({apid:04X})"
            else:
                return None, "APID not available for current service"
                
        elif hash_logic == "sid+pmtpid":
            # SID + PMTPID
            if pmtpid > 0:
                hash_value = f"{sid:04X}{pmtpid:04X}"
                logic_name = f"SID ({sid:04X}) + PMTPID ({pmtpid:04X})"
            else:
                return None, "PMTPID not available for current service"
        
        elif hash_logic == "crc32_original":
            # المنطق الأصلي من السكريبت (للكايد 2600)
            try:
                hash_value_int = get_hash_original(session)
                hash_value = f"{hash_value_int:08X}"  # Capital letters
                logic_name = "CRC32 Original (CAID 2600)"
            except Exception as e:
                return None, f"Error in CRC32 Original: {str(e)}"
            
        elif hash_logic == "crc32_new_logic":
            # المنطق الجديد المصحح: 1_1_201_281_DCA2DA0 (مع namespace حقيقي)
            if vpid > 0 and apid > 0 and namespace > 0:
                # تحويل القيم من عشري إلى سداسي بدون أصفار بادئة
                vpid_hex = f"{vpid:04X}".lstrip('0') or '0'
                apid_hex = f"{apid:04X}".lstrip('0') or '0'
                
                # استخدام namespace الحقيقي من القناة (بدون الصفر البادئ)
                namespace_hex = f"{namespace:08X}".lstrip('0') or '0'
                
                hash_input = f"1_1_{vpid_hex}_{apid_hex}_{namespace_hex}"
                crc32_hash = zlib.crc32(hash_input.encode()) & 0xffffffff
                hash_value = f"{crc32_hash:08X}"  # Capital letters
                logic_name = f"CRC32 New Logic: {hash_input}"
                print(f"CRC32 Input: {hash_input}, Hash: {hash_value}")
            else:
                missing = []
                if vpid == 0: missing.append("VPID")
                if apid == 0: missing.append("APID") 
                if namespace == 0: missing.append("Namespace")
                return None, f"Missing required data for CRC32 logic: {', '.join(missing)}"
        
        if hash_value:
            return hash_value.upper(), logic_name  # تأكيد الحروف الكبيرة
        else:
            return None, f"Unknown hash logic: {hash_logic}"
            
    except Exception as e:
        print(f"Error in get_selected_hash: {e}")
        return None, f"Error generating hash: {str(e)}"

class AboutScreen(Screen):
    """شاشة معلومات عن الإضافة والمطور"""
    skin = """
    <screen position="center,center" flags="wfNoBorder" cornerRadius="25" size="850,600" backgroundColor="#63000000" title="About E2 BISS Key Editor">
        <widget name="title" position="center,20" size="500,60" font="Regular;35" halign="center" valign="center" foregroundColor="#FFD700" backgroundColor="#3C110011" cornerRadius="15" />
        
        <!-- معلومات المطور -->
        <widget name="developer_label" cornerRadius="10" position="50,100" size="250,40" font="Regular;25" halign="center" valign="center" foregroundColor="#4169E1" backgroundColor="#3C110011" />
        <widget name="developer_value" cornerRadius="10" position="290,100" size="490,40" font="Regular;25" halign="center" valign="center" foregroundColor="white" backgroundColor="#3C110011" />
        
        <!-- معلومات الإصدار -->
        <widget name="version_label" cornerRadius="10" position="50,150" size="250,40" font="Regular;25" halign="center" valign="center" foregroundColor="#4169E1" backgroundColor="#3C110011" />
        <widget name="version_value" cornerRadius="10" position="290,150" size="490,40" font="Regular;25" halign="center" valign="center" foregroundColor="white" backgroundColor="#3C110011" />
        
        <!-- تاريخ التطوير -->
        <widget name="date_label" cornerRadius="10" position="50,200" size="250,40" font="Regular;25" halign="center" valign="center" foregroundColor="#4169E1" backgroundColor="#3C110011" />
        <widget name="date_value" cornerRadius="10" position="290,200" size="490,40" font="Regular;25" halign="center" valign="center" foregroundColor="white" backgroundColor="#3C110011" />
        
        <!-- ميزات الإضافة -->
        <widget name="features_title" transparent="1" position="center,260" size="300,40" font="Regular;28" halign="center" valign="center" foregroundColor="#FF6347" backgroundColor="#3C110011" />
        
        <!-- قائمة الميزات -->
        <widget name="feature1" cornerRadius="10" position="50,310" size="730,35" font="Regular;22" halign="left" valign="center" foregroundColor="#98FB98" backgroundColor="#3C110011" />
        <widget name="feature2" cornerRadius="10" position="50,350" size="730,35" font="Regular;22" halign="left" valign="center" foregroundColor="#98FB98" backgroundColor="#3C110011" />
        <widget name="feature3" cornerRadius="10" position="50,390" size="730,35" font="Regular;22" halign="left" valign="center" foregroundColor="#98FB98" backgroundColor="#3C110011" />
        <widget name="feature4" cornerRadius="10" position="50,430" size="730,35" font="Regular;22" halign="left" valign="center" foregroundColor="#98FB98" backgroundColor="#3C110011" />
        <widget name="feature5" cornerRadius="10" position="50,470" size="730,35" font="Regular;22" halign="left" valign="center" foregroundColor="#98FB98" backgroundColor="#3C110011" />
        
        <!-- شعار أو رمز -->
        <!--ePixmap name="icon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/E2BissKeyEditor/plugin.png" position="700,100" size="100,100" zPosition="1" alphatest="blend" /-->
        
        <!-- زر العودة -->
        <widget name="key_red" position="350,520" size="150,45" zPosition="1" font="Regular;25" halign="center" valign="center" backgroundColor="#3C110011" cornerRadius="20" foregroundColor="white" />
        <eLabel name="red_button" position="320,530" size="30,30" zPosition="2" cornerRadius="15" backgroundColor="red" />
        <eLabel name="red_button_effect" position="330,540" zPosition="3" size="10,10" cornerRadius="5" backgroundColor="#3C110011" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        # تعريف العناصر
        self["title"] = Label("About E2 BISS Key Editor")
        
        # معلومات المطور
        self["developer_label"] = Label("Developer")
        self["developer_value"] = Label("Ismail9875 + AI Tools")
        
        # معلومات الإصدار
        self["version_label"] = Label("Version")
        self["version_value"] = Label("1.0")
        
        # تاريخ التطوير
        self["date_label"] = Label("Development Date")
        self["date_value"] = Label("3 Dec 2025")
        
        # عنوان الميزات
        self["features_title"] = Label("••• Main Features •••")
        
        # قائمة الميزات
        self["feature1"] = Label("✓ Add & Validate BISS keys (8-cell & 16-digit)")
        self["feature2"] = Label("✓ Automatic emulator restart after saving")
        self["feature3"] = Label("✓ Multiple hash calculation methods")
        self["feature4"] = Label("✓ Auto-fix for BISS-CA keys")
        self["feature5"] = Label("✓ Channel information display")
        
        # زر العودة
        self["key_red"] = Label("Back")
        
        # خريطة الإجراءات
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"],
            {
                "red": self.close,
                "cancel": self.close,
                "ok": self.close,
            }, -1)
        
        self.onLayoutFinish.append(self.update_display)

    def update_display(self):
        """تحديث العرض"""
        try:
            pass
        except Exception as e:
            print(f"Error updating about screen: {e}")

class MainMenuScreen(Screen):
    """شاشة القائمة الرئيسية لاختيار منطق حساب الهاش"""
    skin = """
    <screen position="center,center" flags="wfNoBorder" cornerRadius="20" size="600,400" backgroundColor="#63000000" title="BISS Hash Logic Selection">
        <widget name="menu" backgroundColorSelected="white" halign="center" valign="center" itemHeight="55" font="bold,28" foregroundColorSelected="black" position="10,70" size="580,280" scrollbarMode="showOnDemand" />
        <widget name="info" position="10,10" size="580,60" font="Regular;25" halign="center" valign="center" />
        <widget name="key_green" position="100,360" size="140,40" zPosition="1" font="Regular;21" halign="center" valign="center" backgroundColor="#63000000" foregroundColor="white" />
        <eLabel name="redButton" position="80,370" size="20,20" zPosition="2" cornerRadius="10" backgroundColor="green" />

        <widget name="key_red" position="360,360" size="140,40" zPosition="1" font="Regular;21" halign="center" valign="center" backgroundColor="#63000000" foregroundColor="white" />
        <eLabel name="redButton" position="340,370" size="20,20" zPosition="2" cornerRadius="10" backgroundColor="red" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        # قائمة خيارات منطق الهاش
        self.logic_options = [
            ("SID + VPID", "sid+vpi"),
            ("SID + APID", "sid+apid"), 
            ("SID + PMTPID", "sid+pmtpid"),
            ("CRC32 Original", "crc32_original"),
            ("CRC32 Standart", "crc32_new_logic")
        ]
        
        self["menu"] = MenuList([])
        self["info"] = Label("Select hash calculation logic")
        self["key_green"] = Label("Select")
        self["key_red"] = Label("Cancel")
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
            {
                "ok": self.ok,
                "green": self.ok,
                "cancel": self.close,
                "red": self.close
            }, -2)
        
        self.onShown.append(self.update_menu)

    def update_menu(self):
        """تحديث قائمة الخيارات"""
        menu_items = []
        current_logic = config.biss.hash_logic.value
        
        for name, value in self.logic_options:
            if value == current_logic:
                menu_items.append(f"> {name}")
            else:
                menu_items.append(f"  {name}")
        
        self["menu"].setList(menu_items)
        
        # عرض معلومات الخدمة الحالية
        channel_name, sid, vpid, apid, pmtpid, namespace, is_encrypted = get_service_info(self.session)
        if channel_name:
            orbital_pos = get_orbital_position(self.session)
            info_text = f"{channel_name} (SID: {sid:04X}, NS: {namespace:08X}, Orb: {orbital_pos})"
            self["info"].setText(info_text)

    def ok(self):
        """اختيار المنطق المحدد"""
        try:
            index = self["menu"].getSelectedIndex()
            if index is not None and 0 <= index < len(self.logic_options):
                selected_logic = self.logic_options[index][1]
                
                # حفظ المنطق المختار
                config.biss.hash_logic.value = selected_logic
                config.biss.save()
                # فتح شاشة إدخال الشيفرة مباشرة وإغلاق هذه الشاشة
                self.session.openWithCallback(self.on_hash_menu_closed, HorizontalHexInput)
        except Exception as e:
            print(f"Error selecting logic: {e}")
            self.session.open(MessageBox, "Error selecting hash logic", MessageBox.TYPE_ERROR, timeout=3)

    def on_hash_menu_closed(self, result=None):
        """Callback عند إغلاق شاشة اختيار الهاش"""
        try:
            # إغلاق شاشة القائمة الرئيسية عند العودة
            self.close()
        except Exception as e:
            print(f"Error in hash menu callback: {e}")
            self.close()

    def close(self):
        """إغلاق الشاشة مباشرة"""
        Screen.close(self)

class HorizontalHexInput(Screen):
    skin = """
    <screen position="center,center" flags="wfNoBorder" size="1000,490" title="E2 BISS Key Editor" backgroundColor="#3C150015" cornerRadius="25" >
        <widget name="title" position="center,0" size="450,60" font="Regular;40" halign="center" valign="center" cornerRadius="15" foregroundColor="red" backgroundColor="#3C110011" />
        <widget name="help" position="center,70" size="880,40" font="Regular;25" halign="center" valign="center" cornerRadius="15" foregroundColor="yellow" backgroundColor="#3C110011" />
        
        <!-- عرض الخلايا بشكل أفقي -->
        <widget name="cells" position="140,110" size="600,60" font="Regular;35" halign="center" valign="center" backgroundColor="#3C110011" foregroundColor="#3C110011" transparent="1" />
        
        <!-- خلايا منفصلة لعرض القيم -->
        <widget name="cell_0" position="120,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_1" position="220,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_2" position="320,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_3" position="420,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_4" position="520,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_5" position="620,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_6" position="720,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        <widget name="cell_7" position="820,130" size="80,60" font="Regular;35" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="white" cornerRadius="15" />
        
        <!-- أزرار الأحرف بشكل عمودي على اليسار -->
        <widget name="key_a" position="10,120" size="80,50" cornerRadius="15" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="#4169E1" foregroundColor="white" />
        <widget name="key_b" position="10,180" size="80,50" cornerRadius="15" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="#4169E1" foregroundColor="white" />
        <widget name="key_c" position="10,240" size="80,50" cornerRadius="15" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="#4169E1" foregroundColor="white" />
        <widget name="key_d" position="10,300" size="80,50" cornerRadius="15" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="#4169E1" foregroundColor="white" />
        <widget name="key_e" position="10,360" size="80,50" cornerRadius="15" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="#4169E1" foregroundColor="white" />
        <widget name="key_f" position="10,420" size="80,50" cornerRadius="15" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="#4169E1" foregroundColor="white" />
        
        <!-- معلومات القناة المفصلة على اليمين -->
        <widget name="channel_name" position="120,240" size="480,35" font="Regular;25" halign="left" valign="center" foregroundColor="yellow" backgroundColor="#3C150015" transparent="1" />
        <widget name="sid_info" position="120,270" size="180,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="vpid_info" position="240,270" size="180,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="apid_info" position="420,270" size="180,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="pmtpid_info" position="600,270" size="180,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="tsid_info" position="120,300" size="180,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="onid_info" position="240,300" size="320,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="namespace_info" position="420,300" size="320,35" font="Regular;22" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        <widget name="service_ref" position="120,330" size="480,35" font="Regular;25" halign="left" valign="center" foregroundColor="#4169E1" backgroundColor="#3C150015" transparent="1" />
        
        <widget source="session.CurrentService" render="Label" font="Regular_bold; 25" position="120,365" size="700,40" halign="left" valign="center" zPosition="25" backgroundColor="#3C150015" foregroundColor="#926F34" transparent="1" >
            <convert type="TransponderInfo"/>
        </widget>

        <!-- معلومات الهاش المختار -->
        <widget name="hash_logic_name" position="120,200" size="380,40" font="Regular;24" halign="left" valign="center" foregroundColor="yellow" backgroundColor="#3C150015" transparent="1" />
        <widget name="hash_value" position="520,200" size="200,40" font="Regular;24" halign="left" zPosition="1" valign="center" foregroundColor="yellow" backgroundColor="#3C150015" cornerRadius="10" transparent="1" />

        <!-- حالة التشفير -->
        <widget name="encryption_status" position="520,240" cornerRadius="20" size="200,30" font="Regular;22" halign="left" valign="center" foregroundColor="yellow" backgroundColor="#3C150015" transparent="1" />
        
        <widget source="session.CurrentService" foregroundColor="yellow" render="Label" font="global_bold; 24" transparent="1" size="300,100" cornerRadius="30" position="670,390" valign="center" halign="center" backgroundColor="red" zPosition="15" >
            <convert type="E2BissKeyEditorCryptInfo">CAIDs</convert>
        </widget>
        
        <!-- Clock and Date -->
        <widget backgroundColor="#3C150015" foregroundColor="white" font="global_bold; 50" zPosition="5" noWrap="1" valign="center" halign="center" position="800,0" render="Label" size="250,70" source="global.CurrentTime" transparent="1"  >
            <convert type="ClockToText">Format: %-H:%M</convert>
        </widget>
        <widget backgroundColor="#3C150015" foregroundColor="white" font="global_bold; 40" zPosition="5" noWrap="1" valign="center" halign="center" position="0,0" render="Label" size="250,70" source="global.CurrentTime" transparent="1"  >
            <convert type="ClockToText">Format: %a.%d.%b</convert>
        </widget>
        
        <!-- Signal Info from Skin Only -->
        <widget source="session.FrontendStatus" render="Progress" position="180,410" size="300,20" backgroundColor="#3C110011" foregroundColor="#926F34" transparent="0" zPosition="5" cornerRadius="15">
            <convert type="FrontendInfo">SNR</convert>
        </widget>
        <widget source="session.FrontendStatus" render="Progress" position="180,450" size="300,20" backgroundColor="#3C110011" transparent="0" foregroundColor="#926F34" zPosition="5" cornerRadius="15">
            <convert type="FrontendInfo">AGC</convert>
        </widget>

        <widget source="session.FrontendStatus" render="Label" position="600,300" foregroundColor="yellow" size="200,70" font="bold; 45" backgroundColor="yellow" halign="center" valign="center" transparent="1">
            <convert type="FrontendInfo">SNRdB</convert>
        </widget>
        
        <widget source="session.FrontendStatus" render="Label" position="500,400" foregroundColor="white" size="98,40" font="bold; 30" backgroundColor="yellow" halign="center" valign="center" transparent="1">
            <convert type="FrontendInfo">SNR</convert>
        </widget>
        <widget source="session.FrontendStatus" render="Label" foregroundColor="white" position="500,440" size="98,40" font="bold; 30" backgroundColor="yellow" halign="center" valign="center" transparent="1"  >
            <convert type="FrontendInfo">AGC</convert>
        </widget>

        <!-- AGC, SNR text -->
        <eLabel name="snr_label" position="120,405" size="60,30" foregroundColor="white" text="SNR" font="Regular_bold; 24" backgroundColor="#3C150015" halign="left" transparent="1" />
        <eLabel name="agc_label" position="120,445" size="60,30" foregroundColor="white" text="AGC" font="Regular_bold; 24" backgroundColor="#3C150015" halign="left" transparent="1" />
        
        <!-- أزرار التحكم في الأسفل -->
        <widget name="key_green" position="860,270" size="180,50" zPosition="1" font="Regular;30" halign="left" valign="center" backgroundColor="#3C150015" cornerRadius="25" foregroundColor="green" transparent="1" />
        <eLabel name="green_Button" position="810,280" size="30,30" zPosition="2" cornerRadius="25" backgroundColor="green" />
        <eLabel name="greenButtonEffect" position="820,290" zPosition="3" size="10,10" cornerRadius="10" backgroundColor="#3C150015" />

        <widget name="key_red" position="860,220" size="180,50" zPosition="1" font="Regular;30" halign="left" valign="center" backgroundColor="#3C150015" cornerRadius="25" foregroundColor="red" transparent="1" />
        <eLabel name="red_Button" position="810,230" size="30,30" zPosition="2" cornerRadius="25" backgroundColor="red" />
        <eLabel name="redButtonEffect" position="820,240" zPosition="3" size="10,10" cornerRadius="10" backgroundColor="#3C150015" />
        
        <widget name="key_blue" position="860,320" size="180,50" zPosition="1" font="Regular;30" halign="left" valign="center" backgroundColor="#3C150015" cornerRadius="25" foregroundColor="blue" transparent="1" />
        <eLabel name="blue_Button" position="810,330" size="30,30" zPosition="2" cornerRadius="25" backgroundColor="blue" />
        <eLabel name="blueButtonEffect" position="820,340" zPosition="3" size="10,10" cornerRadius="10" backgroundColor="#3C150015" />

        <!-- تلميح زر Info -->
        <!--widget name="info_hint" position="50,460" size="300,25" font="Regular;20" halign="left" valign="center" foregroundColor="#AAAAAA" backgroundColor="transparent" /-->
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.cells = ["00", "00", "00", "00", "00", "00", "00", "00"]
        self.current_cell = 0
        self.current_char = 0
        self.selected_letter_index = 0
        self.selected_hash = None
        self.hash_logic_name = ""
        self.tuner_data = {}
        self.close_directly = True
        
        # قائمة الأحرف
        self.letters = ["A", "B", "C", "D", "E", "F"]
        
        # تعريف جميع العناصر
        self["title"] = Label("E2 BISS Key Editor")
        self["help"] = Label("Use 0-9 keys for numbers, UP/DOWN for letters, LEFT/RIGHT for cells")
        self["cells"] = Label("")  # العرض القديم
        
        # تعريف الخلايا المنفصلة
        for i in range(8):
            self[f"cell_{i}"] = Label("00")
        
        # معلومات القناة المفصلة
        self["channel_name"] = Label("")
        self["sid_info"] = Label("")
        self["vpid_info"] = Label("")
        self["apid_info"] = Label("")
        self["pmtpid_info"] = Label("")
        self["tsid_info"] = Label("")
        self["onid_info"] = Label("")
        self["namespace_info"] = Label("")
        self["service_ref"] = Label("")
        
        # معلومات الهاش
        self["hash_logic_name"] = Label("")
        self["hash_value"] = Label("")
        self["encryption_status"] = Label("")
        
        # تلميح زر Info (يمكن تفعيله إذا أردت)
        # self["info_hint"] = Label("Press INFO button for about")
        
        # أزرار الأحرف بشكل عمودي
        self["key_a"] = Label("A")
        self["key_b"] = Label("B")
        self["key_c"] = Label("C")
        self["key_d"] = Label("D")
        self["key_e"] = Label("E")
        self["key_f"] = Label("F")
        
        # أزرار التحكم
        self["key_green"] = Label("Save")
        self["key_red"] = Label("Exit")
        self["key_blue"] = Label("Reset")
        
        # استخدام InfoActions بدلاً من ColorActions لزر الـ Info
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "DirectionActions", "NumberActions", "MenuActions", "InfoActions"],
            {
                "up": self.up,
                "down": self.down,
                "left": self.left,
                "right": self.right,
                "ok": self.input_selected_letter,
                "cancel": self.close_direct,
                "green": self.validate_and_save,
                "red": self.close_direct,
                "blue": self.reset_all,
                "menu": self.open_hash_menu,
                "info": self.open_about_screen,  # زر Info الفعلي
                "0": lambda: self.input_char("0"),
                "1": lambda: self.input_char("1"),
                "2": lambda: self.input_char("2"),
                "3": lambda: self.input_char("3"),
                "4": lambda: self.input_char("4"),
                "5": lambda: self.input_char("5"),
                "6": lambda: self.input_char("6"),
                "7": lambda: self.input_char("7"),
                "8": lambda: self.input_char("8"),
                "9": lambda: self.input_char("9"),
            }, -1)
        
        # إضافة أزرار الأحرف إلى ActionMap للإدخال المباشر
        self.letter_actions = {
            "a": lambda: self.input_char("A"),
            "b": lambda: self.input_char("B"),
            "c": lambda: self.input_char("C"),
            "d": lambda: self.input_char("D"),
            "e": lambda: self.input_char("E"),
            "f": lambda: self.input_char("F"),
        }
        
        for key, action in self.letter_actions.items():
            self["actions"].actions[key] = action
        
        self.onLayoutFinish.append(self.update_display)
        self.onLayoutFinish.append(self.update_channel_info)
        self.onLayoutFinish.append(self.update_hash_display)
        self.onLayoutFinish.append(self.update_letter_buttons)
        
        # حساب الهاش تلقائياً عند بدء التشغيل
        self.onShown.append(self.auto_calculate_hash)
        
        # تفريغ الخانات تلقائياً عند بدء التشغيل
        self.auto_reset_on_startup()

    def update_display(self):
        """تحديث جميع عناصر العرض"""
        try:
            # تحديث الخلايا المنفصلة
            for i in range(8):
                cell_widget = self[f"cell_{i}"]
                cell_value = self.cells[i]
                cell_widget.setText(cell_value)
                
                # تحديث الألوان بناءً على الخلية النشطة
                if i == self.current_cell:
                    # الخلية النشطة - خلفية زرقاء فاتحة ونص أسود
                    cell_widget.instance.setBackgroundColor(gRGB(0x926F34))  # ذهبي
                    cell_widget.instance.setForegroundColor(gRGB(0xFFFFFF))  # أبيض
                else:
                    # الخلايا غير النشطة - خلفية داكنة ونص أبيض
                    cell_widget.instance.setBackgroundColor(gRGB(0x420017))  # بني داكن
                    cell_widget.instance.setForegroundColor(gRGB(0xFFEE8C))  # أصفر فاقع
            
            # تحديث ألوان أزرار الأحرف
            self.update_letter_buttons()
            
            # تحديث العرض النصي القديم (للتوافق)
            self["cells"].setText(self.get_cells_display())
            
        except Exception as e:
            print(f"Error in update_display: {e}")

    def update_letter_buttons(self):
        """تحديث ألوان أزرار الأحرف بناءً على الحرف المختار"""
        try:
            for i, letter in enumerate(self.letters):
                widget = self[f"key_{letter.lower()}"]
                if i == self.selected_letter_index:
                    # الحرف المختار - خلفية برتقالية ونص أسود
                    widget.instance.setBackgroundColor(gRGB(0xFFA500))  # برتقالي
                    widget.instance.setForegroundColor(gRGB(0x000000))  # أسود
                else:
                    # الأحرف غير المختارة - خلفية زرقاء ونص أبيض
                    widget.instance.setBackgroundColor(gRGB(0x4169E1))  # أزرق ملكي
                    widget.instance.setForegroundColor(gRGB(0xFFFFFF))  # أبيض
        except Exception as e:
            print(f"Error updating letter buttons: {e}")

    def get_cells_display(self):
        """الحصول على نص عرض الخلايا (للتوافق مع الكود القديم)"""
        display = ""
        for i, cell in enumerate(self.cells):
            if i == self.current_cell:
                display += f"[{cell}] "
            else:
                display += f" {cell}  "
        return display.strip()

    def close_direct(self):
        """إغلاق مباشر دون تحديث أي displays"""
        self.close_directly = True
        self.close()

    def close(self):
        """إغلاق الشاشة مع التحكم في السلوك"""
        try:
            if hasattr(self, 'signal_timer'):
                self.signal_timer.stop()
        except:
            pass
        
        if self.close_directly:
            # إغلاق مباشر دون أي عمليات إضافية
            Screen.close(self)
        else:
            # إغلاق عادي مع تحديثات (لحالات أخرى)
            Screen.close(self)
        
        self.close_directly = False  # إعادة تعيين المتغير

    def auto_calculate_hash(self):
        """حساب الهاش تلقائياً عند بدء التشغيل"""
        try:
            hash_value, logic_info = get_selected_hash(self.session)
            
            if hash_value:
                self.selected_hash = hash_value.upper()  # Capital letters
                self.hash_logic_name = logic_info
                self.update_hash_display()  # تحديث العرض
                print(f"Auto-calculated hash: {hash_value} using {logic_info}")
            else:
                print(f"Auto-hash calculation failed: {logic_info}")
                
        except Exception as e:
            print(f"Error in auto hash calculation: {e}")

    def update_channel_info(self):
        """تحديث معلومات القناة المفصلة"""
        try:
            service_info = self.get_detailed_service_info()
            
            if not service_info or not service_info.get('channel_name'):
                self.set_default_channel_info()
                return
            
            # معلومات القناة الأساسية
            self["channel_name"].setText(service_info['channel_name'])
            self["sid_info"].setText(f"SID {service_info['sid']:04X}")
            self["vpid_info"].setText(f"VPID {service_info['vpid']:04X}")
            self["apid_info"].setText(f"APID {service_info['apid']:04X}")
            self["pmtpid_info"].setText(f"PMTPID {service_info['pmtpid']:04X}")
            self["tsid_info"].setText(f"TSID {service_info['tsid']:04X}")
            self["onid_info"].setText(f"ONID {service_info['onid']:04X}")
            self["namespace_info"].setText(f"NS {service_info['namespace']:08X}")
            self["service_ref"].setText(f"Ref {service_info['service_ref']}")
            
            # حالة التشفير
            encryption_text = "Encrypted" if service_info['is_encrypted'] else "FTA"
            self["encryption_status"].setText(encryption_text)
            
        except Exception as e:
            print(f"Error updating channel info: {e}")
            self.set_default_channel_info()

    def get_detailed_service_info(self):
        """الحصول على معلومات تفصيلية عن الخدمة الحالية"""
        try:
            service = self.session.nav.getCurrentService()
            if not service:
                return None

            service_ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not service_ref:
                return None

            # الحصول على المعلومات الأساسية
            service_handler = eServiceCenter.getInstance()
            service_info_obj = service_handler.info(service_ref)
            channel_name = service_info_obj.getName(service_ref) if service_info_obj else "Unknown"

            # الحصول على جميع المعرفات
            sid = service_ref.getUnsignedData(1)  # SID
            tsid = service_ref.getUnsignedData(2)  # TSID
            onid = service_ref.getUnsignedData(3)  # ONID
            namespace = service_ref.getUnsignedData(4)  # Namespace
            
            # الحصول على PIDs من معلومات الخدمة
            info = service.info()
            if info:
                vpid = info.getInfo(iServiceInformation.sVideoPID)
                apid = info.getInfo(iServiceInformation.sAudioPID)
                pmtpid = info.getInfo(iServiceInformation.sPMTPID)
                is_encrypted = info.getInfo(iServiceInformation.sIsCrypted) == 1
            else:
                vpid = apid = pmtpid = 0
                is_encrypted = False

            return {
                'channel_name': channel_name,
                'sid': sid,
                'vpid': vpid,
                'apid': apid,
                'pmtpid': pmtpid,
                'tsid': tsid,
                'onid': onid,
                'namespace': namespace,
                'service_ref': str(service_ref.toString()),
                'is_encrypted': is_encrypted
            }
            
        except Exception as e:
            print(f"Error getting detailed service info: {e}")
            return None

    def set_default_channel_info(self):
        """تعيين معلومات القناة الافتراضية"""
        self["channel_name"].setText("No channel info")
        self["sid_info"].setText("SID: N/A")
        self["vpid_info"].setText("VPID: N/A")
        self["apid_info"].setText("APID: N/A")
        self["pmtpid_info"].setText("PMTPID: N/A")
        self["tsid_info"].setText("TSID: N/A")
        self["onid_info"].setText("ONID: N/A")
        self["namespace_info"].setText("Namespace: N/A")
        self["service_ref"].setText("Ref: N/A")
        self["encryption_status"].setText("No signal")

    def update_hash_display(self):
        """تحديث عرض معلومات الهاش"""
        try:
            # تحديث اسم منطق الهاش
            logic_map = {
                "sid+vpi": "SID + VPID",
                "sid+apid": "SID + APID", 
                "sid+pmtpid": "SID + PMTPID",
                "crc32_original": "CRC32 Original",
                "crc32_new_logic": "CRC32 Standard"
            }
            
            current_logic = config.biss.hash_logic.value
            logic_name = logic_map.get(current_logic, "Unknown")
            self["hash_logic_name"].setText(f"Hash Logic: {logic_name}")
            
            # تحديث قيمة الهاش إذا كانت موجودة (Capital letters)
            if self.selected_hash:
                self["hash_value"].setText(self.selected_hash.upper())
            else:
                self["hash_value"].setText("")
                
        except Exception as e:
            print(f"Error updating hash display: {e}")

    def open_hash_menu(self):
        """فتح شاشة اختيار الهاش عند الضغط على زر Menu"""
        try:
            self.session.openWithCallback(self.on_hash_menu_closed, MainMenuScreen)
        except Exception as e:
            print(f"Error opening hash menu: {e}")
            self.session.open(MessageBox, "Error opening hash selection menu", MessageBox.TYPE_ERROR)

    def on_hash_menu_closed(self, result=None):
        """Callback عند إغلاق شاشة اختيار الهاش"""
        try:
            # حساب الهاش تلقائياً عند العودة من شاشة الاختيار
            self.auto_calculate_hash()
            # تحديث معلومات القناة
            self.update_channel_info()
        except Exception as e:
            print(f"Error in hash menu callback: {e}")

    def auto_reset_on_startup(self):
        """تفريغ جميع الخانات تلقائياً عند بدء التشغيل"""
        try:
            # تفريغ الخانات المحلية
            self.cells = ["00", "00", "00", "00", "00", "00", "00", "00"]
            self.current_cell = 0
            self.current_char = 0
            self.selected_letter_index = 0
            self.selected_hash = None
            self.hash_logic_name = ""
            
            # تفريغ الخانات في config
            auto_reset_all_cells()
            
            print("All BISS cells reset to default on startup")
        except Exception as e:
            print(f"Error in auto reset on startup: {e}")

    def is_valid_hex_char(self, char):
        """التحقق إذا كان الحرف مسموحاً به (0-9, A-F, a-f)"""
        return char in '0123456789ABCDEFabcdef'

    def input_char(self, char):
        """إدخال حرف في الموضع الحالي مع التحقق من الصحة"""
        # التحقق من أن الحرف مسموح به
        if not self.is_valid_hex_char(char):
            return
        
        # تحويل الحرف إلى uppercase للتأكد من التنسيق
        char = char.upper()
        
        current_value = self.cells[self.current_cell]
        
        if self.current_char == 0:
            # استبدال الحرف الأول
            new_value = char + current_value[1]
        else:
            # استبدال الحرف الثاني
            new_value = current_value[0] + char
        
        self.cells[self.current_cell] = new_value
        
        # الانتقال التلقائي للحرف التالي
        self.auto_move_next()
        
        self.update_display()

    def input_selected_letter(self):
        """إدخال الحرف المحدد بالأزرار العلوية والسفلية"""
        selected_letter = self.letters[self.selected_letter_index]
        self.input_char(selected_letter)

    def auto_move_next(self):
        """الانتقال التلقائي للحرف أو الخلية التالية"""
        if self.current_char == 0:
            # الانتقال إلى الحرف الثاني في نفس الخلية
            self.current_char = 1
        else:
            # الانتقال إلى الخلية التالية (الحرف الأول)
            self.current_char = 0
            if self.current_cell < 7:
                self.current_cell += 1

    def up(self):
        """التنقل بين الأحرف (UP) - للأعلى في العمود"""
        if self.selected_letter_index > 0:
            self.selected_letter_index -= 1
        else:
            self.selected_letter_index = len(self.letters) - 1  # الانتقال للأسفل
        self.update_display()

    def down(self):
        """التنقل بين الأحرف (DOWN) - للأسفل في العمود"""
        if self.selected_letter_index < len(self.letters) - 1:
            self.selected_letter_index += 1
        else:
            self.selected_letter_index = 0  # الانتقال للأعلى
        self.update_display()

    def left(self):
        """الانتقال إلى الخلية السابقة (LEFT) - في الصف الأفقي"""
        if self.current_cell > 0:
            self.current_cell -= 1
            self.current_char = 0
            self.update_display()

    def right(self):
        """الانتقال إلى الخلية التالية (RIGHT) - في الصف الأفقي"""
        if self.current_cell < 7:
            self.current_cell += 1
            self.current_char = 0
            self.update_display()

    def reset_all(self):
        """إعادة تعيين جميع المدخلات إلى الحالة الافتراضية (الزر الأزرق)"""
        try:
            self.session.openWithCallback(
                self.confirm_reset,
                MessageBox,
                "Are you sure you want to reset all fields?\nThis will clear all cells and remove selected hash.",
                MessageBox.TYPE_YESNO
            )
        except Exception as e:
            print(f"Error in reset_all: {e}")

    def confirm_reset(self, result):
        """تأكيد عملية إعادة التعيين"""
        if result:
            try:
                # إعادة تعيين الخلايا إلى القيم الافتراضية
                self.cells = ["00", "00", "00", "00", "00", "00", "00", "00"]
                self.current_cell = 0
                self.current_char = 0
                self.selected_letter_index = 0
                self.selected_hash = None
                self.hash_logic_name = ""
                
                # تفريغ الخانات في config
                auto_reset_all_cells()
                
                # تحديث العرض
                self.update_display()
                self.update_hash_display()
                
                # عرض رسالة نجاح
                self.session.open(
                    MessageBox,
                    "All fields have been reset to default values.",
                    MessageBox.TYPE_INFO,
                    timeout=3
                )
            except Exception as e:
                print(f"Error resetting fields: {e}")
                self.session.open(
                    MessageBox,
                    "Error resetting fields. Please try again.",
                    MessageBox.TYPE_ERROR,
                    timeout=2
                )

    def open_about_screen(self):
        """فتح شاشة معلومات الإضافة عند الضغط على زر Info"""
        try:
            self.session.open(AboutScreen)
        except Exception as e:
            print(f"Error opening about screen: {e}")
            self.session.open(MessageBox, "Error opening about screen", MessageBox.TYPE_ERROR)

    def validate_and_save(self):
        """التحقق من صحة الشيفرة قبل الحفظ"""
        try:
            # التحقق من وجود هاش محدد
            if not self.selected_hash:
                self.session.open(MessageBox, "No hash available! Hash is calculated automatically.", MessageBox.TYPE_ERROR)
                return
            
            # التحقق من صحة الشيفرة وتصحيحها تلقائياً
            fixed_cells, valid, msg = validate_and_fix_biss_8cells(self.cells)
            
            if fixed_cells is None:
                self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR)
                return
            
            if valid:
                # إذا كانت الشيفرة صالحة، حفظ مباشرة
                self.doSave(fixed_cells)
            else:
                # إذا كانت تحتاج تصحيح، حفظ مع التصحيح
                self.doSave(fixed_cells)
                
        except Exception as e:
            print(f"Error in validate_and_save: {e}")
            self.session.open(MessageBox, f"Validation error: {str(e)}", MessageBox.TYPE_ERROR)

    def doSave(self, fixed_cells):
        """حفظ الشيفرة إلى ملف/ملفات SoftCam.Key"""
        try:
            # تحديث الخلايا المحلية بالقيم المصححة
            self.cells = fixed_cells
            self.update_display()
            
            # حفظ القيم في config
            config.biss.cell_a.value = self.cells[0]
            config.biss.cell_b.value = self.cells[1]
            config.biss.cell_c.value = self.cells[2]
            config.biss.cell_d.value = self.cells[3]
            config.biss.cell_e.value = self.cells[4]
            config.biss.cell_f.value = self.cells[5]
            config.biss.cell_g.value = self.cells[6]
            config.biss.cell_h.value = self.cells[7]
            config.biss.save()
            
            # إنشاء الشيفرة الكاملة
            key16 = "".join(fixed_cells)
            channel_info = self.get_channel_info_for_backup()

            # إنشاء سطر المفتاح
            key_line = f"F {self.selected_hash} 00 {key16} ; E2BissKeyEditor {datetime.now().strftime('%Y-%m-%d %H:%M')} {channel_info}"
            
            # حفظ المفتاح في جميع المسارات
            save_success, save_message = save_key_to_all_paths(key_line)
            
            # ✅ إعادة تشغيل المحاكي تلقائياً بعد الحفظ
            restart_success = False
            if save_success:
                restart_success = restart_emu()
            
            # بناء رسالة النتيجة
            if save_success:
                if restart_success:
                    message = (f"✅ Key saved successfully!\n\n"
                              f"🔑 Hash: {self.selected_hash}\n"
                              f"🔐 Key: {key16}\n"
                              f"📁 {save_message}\n"
                              f"🔄 Emulator restarted automatically")
                else:
                    message = (f"✅ Key saved successfully!\n\n"
                              f"🔑 Hash: {self.selected_hash}\n"
                              f"🔐 Key: {key16}\n"
                              f"📁 {save_message}\n"
                              f"⚠️ Emulator restart failed - please restart manually")
            else:
                message = f"❌ Save failed!\n\n{save_message}"
        
            self.session.open(
                MessageBox, 
                message, 
                MessageBox.TYPE_INFO if save_success else MessageBox.TYPE_ERROR, 
                timeout=10
            )
            
            # تفريغ الخانات بعد الحفظ الناجح
            if save_success:
                self.auto_reset_on_startup()
            
        except Exception as e:
            print(f"Error in doSave: {e}")
            self.session.open(MessageBox, f"Save failed:\n{e}", MessageBox.TYPE_ERROR, timeout=3)

    def get_channel_info_for_backup(self):
        """الحصول على معلومات القناة للحفظ في النسخة الاحتياطية"""
        try:
            service_info = self.get_detailed_service_info()
            if service_info and service_info.get('channel_name'):
                return f"Channel: {service_info['channel_name']}, SID: {service_info['sid']:04X}"
            return "Unknown Channel"
        except:
            return "Unknown Channel"

def main(session, **kwargs):
    # تفريغ جميع الخانات تلقائياً قبل فتح الواجهة
    auto_reset_all_cells()
    # فتح شاشة إدخال الشيفرة مباشرة
    session.open(HorizontalHexInput)

def Plugins(**kwargs): 
    return PluginDescriptor(
        name="E2 BISS Key Editor",
        description="Add & Validate Biss keys with Auto Restart & Backup",
        icon="plugin.png",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main)